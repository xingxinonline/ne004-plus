/*
 * @Author       : panxinhao
 * @Date         : 2023-07-19 16:12:18
 * @LastEditors  : panxinhao
 * @LastEditTime : 2023-08-07 16:03:39
 * @FilePath     : \\testbench_base\\riscv64_default\\mfcc\\mfcc_core.c
 * @Description  :
 *
 * Copyright (c) 2023 by xinhao.pan@pimchip.cn, All Rights Reserved.
 */

#include <stdbool.h>
#include <stdint.h>
#ifdef MAC
    #include <string.h>
    #include <stdlib.h>
    #include <stddef.h>
#elif RISCV
    #include "malloc.h"
#elif ARM_MATH_DSP
    #include <string.h>
    #include <stdlib.h>
    #include <stddef.h>
#endif
#include "mfcc_core.h"
#include "mfcc_fft.h"
#include "mfcc_tools.h"
#include "mfcc_fft.h"
#include "mfcc_fft_table.h"

int16_t  FRAME_LEN;

// void ComputePowerSpectrum(int16_t *fft_frame, int32_t frame_len, int32_t *waveform)
// {
//     waveform[0] = fft_frame[0] * fft_frame[0];
//     for (int16_t i = 1; i < frame_len - 1; i++)
//     {
//         waveform[i] = fft_frame[2 * i] * fft_frame[2 * i] + fft_frame[2 * i + 1] * fft_frame[2 * i + 1];
//     }
//     waveform[frame_len - 1] = fft_frame[1] * fft_frame[1];
// }

void ComputePowerSpectrum(int32_t *fft_frame, int32_t frame_len, int32_t *waveform)
{
    waveform[0] = fft_frame[0] * fft_frame[0];
    for (int16_t i = 1; i < frame_len - 1; i++)
    {
        waveform[i] = fft_frame[2 * i] * fft_frame[2 * i] + fft_frame[2 * i + 1] * fft_frame[2 * i + 1];
    }
    waveform[frame_len - 1] = fft_frame[1] * fft_frame[1];
}

void ComputeMfccCore(TMFCC *mfcc, BaseFloat *feature)
{
    int16_t  *signal_frame = mfcc->window;
    // /* FFT SOFTWARE */
    // for (int16_t i = 0; i < FRAME_LEN; i++)
    // {
    //     mfcc->fft_out[2 * i] = signal_frame[i];
    //     mfcc->fft_out[2 * i + 1] = 0;
    // }
    // arm_radix4_butterfly_int16(mfcc->fft_out, (uint32_t)FRAME_LEN, twiddleCoef_1024_q15, 1);
    // arm_bitreversal_16((uint16_t *) mfcc->fft_out, 992, armBitRevIndexTable_fixed_1024);
    /* FFT HARDWARE START */
    for (int16_t i = 0; i < FRAME_LEN; i++)
    {
        mfcc->fft_out[i] = signal_frame[i];
    }
    extern void fft_hardware(int32_t *src_addr);
    fft_hardware(mfcc->fft_out);
    /* FFT HARDWARE END */
    ComputePowerSpectrum(mfcc->fft_out, FRAME_LEN, mfcc->wavform);
    MelBankCompute(mfcc, mfcc->wavform, mfcc->mel_energies, &(mfcc->mel_len));
    ApplyFloor_Int32(mfcc->mel_energies, mfcc->mel_len, 1);
    ApplyLog_Int32(mfcc->mel_energies, mfcc->mel_len);
#ifdef MAC
    memset(feature, 0, sizeof(BaseFloat) * mfcc->dct_row_len);
#elif RISCV
    // TOFIX
    mymemset(feature, 0, sizeof(BaseFloat) * mfcc->dct_row_len);
#elif ARM_MATH_DSP
    memset(feature, 0, sizeof(BaseFloat) * mfcc->dct_row_len);
#endif
    for (int32_t i = 0; i < mfcc->dct_row_len; ++i)   // 问题出在这里
    {
        int32_t row_sum = 0;
        for (int32_t j = 0; j < mfcc->dct_col_len; ++j)
        {
            row_sum += mfcc->dct_weights[i * mfcc->dct_col_len + j] * mfcc->mel_energies[j];
        }
        feature[i] = row_sum;
    }
    for (int32_t i = 0; i < mfcc->dct_row_len; ++i)
    {
        feature[i] = feature[i] * mfcc->lifter_coeffs[i] / 32767.0f;
    }
}
