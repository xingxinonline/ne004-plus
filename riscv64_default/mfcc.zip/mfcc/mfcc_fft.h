#ifndef __MFCC_FFT_H__
#define __MFCC_FFT_H__

#include <stdint.h>
/*FFT radix 4 int16*/
void arm_radix4_butterfly_int16(
  int16_t * pSrc16,
  uint32_t fftLen,
  const int16_t * pCoef16,
  uint32_t twidCoefModifier);

/* bit reverse */
void arm_bitreversal_16(
  uint16_t *pSrc,
  const uint16_t bitRevLen,
  const uint16_t *pBitRevTab);
#endif