#ifdef MAC
    #include <stdlib.h>
    #include <string.h>
#elif RISCV
    #include "malloc.h"
#elif ARM_MATH_DSP
    #include <stdlib.h>
    #include <string.h>
#endif
#include "mfcc_mel.h"
#include "mfcc_win.h"
#include "mfcc_tools.h"
#include "mfcc_fft.h"
extern int16_t          FRAME_LEN;
extern int16_t          STAGE;
extern inline BaseFloat MelScale(BaseFloat freq);
extern inline BaseFloat InverseMelScale(BaseFloat mel_freq);

void MfccOptInit(TMFCC *mfcc)
{
    TMFCCOPT *mfcc_opt = mfcc->mfcc_opt;
    mfcc_opt->num_ceps = 10;
    mfcc_opt->cepstral_lifter = 22.0;
    mfcc_opt->num_bins = 10;
    mfcc_opt->samp_freq = 16000.0;
    mfcc_opt->frame_length_ms = 40.0;
    mfcc_opt->frame_shift_ms = 20.0;
    mfcc_opt->preemph_coeff = round(0.97 * 256);
    mfcc_opt->snip_edges = 1;
}

void MelBankCompute(TMFCC   *mfcc,
                    int32_t *power_spectrum,
                    int32_t *mel_energies_out,
                    int32_t *mel_energy_out_len)
{
    for (int32_t i = 0; i < mfcc->mel_bank->bin_len; i++)
    {
        int16_t offset = mfcc->mel_bank->keys[i];
        uint8_t sizes = mfcc->mel_bank->sizes[i];
        int32_t energy = InnerProduct_Int32_ShiftRight(mfcc->mel_bank->bins + offset, power_spectrum + offset, sizes, 12);
        mel_energies_out[i] = energy;
    }
    *mel_energy_out_len = mfcc->mel_bank->bin_len;
}

TMELBANK *CreateMelBanks(TMFCC *mfcc)
{
    // int32_t scales = 1 << BINARY_POINT;
    int32_t num_bins = mfcc->mfcc_opt->num_bins;
    // int32_t window_length_padded = PaddedWindowSize(WindowSize(mfcc->mfcc_opt)); // 512
    // int32_t num_fft_bins = window_length_padded / 2;                             // 256 bins
    uint16_t bins[897] = { 35, 82, 129, 175, 220, 264, 307, 350, 391, 432, 472, 511, 473, 434, 397, 360, 324, 288, 253, 218, 184, 151, 118, 85, 53, 21, 0, 38, 77, 114, 151, 187, 223, 258, 293, 327, 360, 393, 426, 458, 490, 502, 471, 441, 411, 381, 352, 323, 294, 266, 238, 211, 184, 157, 130, 104, 78, 53, 27, 2, 9, 40, 70, 100, 130, 159, 188, 217, 245, 273, 300, 327, 354, 381, 407, 433, 458, 484, 509, 490, 465, 441, 417, 393, 370, 347, 324, 301, 278, 256, 234, 212, 190, 169, 148, 127, 106, 85, 65, 44, 24, 4, 21, 46, 70, 94, 118, 141, 164, 187, 210, 233, 255, 277, 299, 321, 342, 363, 384, 405, 426, 446, 467, 487, 507, 496, 477, 457, 438, 419, 400, 381, 363, 344, 326, 308, 290, 272, 254, 236, 219, 201, 184, 167, 150, 133, 117, 100, 84, 67, 51, 35, 19, 3, 15, 34, 54, 73, 92, 111, 130, 148, 167, 185, 203, 221, 239, 257, 275, 292, 310, 327, 344, 361, 378, 394, 411, 427, 444, 460, 476, 492, 508, 499, 484, 468, 453, 437, 422, 407, 392, 377, 362, 347, 333, 318, 304, 289, 275, 261, 247, 233, 219, 205, 191, 178, 164, 150, 137, 124, 110, 97, 84, 71, 58, 45, 32, 20, 7, 12, 27, 43, 58, 74, 89, 104, 119, 134, 149, 164, 178, 193, 207, 222, 236, 250, 264, 278, 292, 306, 320, 333, 347, 361, 374, 387, 401, 414, 427, 440, 453, 466, 479, 491, 504, 506, 494, 481, 469, 457, 444, 432, 420, 408, 396, 384, 372, 360, 349, 337, 325, 314, 302, 291, 279, 268, 257, 245, 234, 223, 212, 201, 190, 179, 168, 158, 147, 136, 125, 115, 104, 94, 83, 73, 63, 52, 42, 32, 22, 12, 1, 5, 17, 30, 42, 54, 67, 79, 91, 103, 115, 127, 139, 151, 162, 174, 186, 197, 209, 220, 232, 243, 254, 266, 277, 288, 299, 310, 321, 332, 343, 353, 364, 375, 386, 396, 407, 417, 428, 438, 448, 459, 469, 479, 489, 499, 510, 503, 493, 484, 474, 464, 454, 444, 434, 425, 415, 406, 396, 386, 377, 367, 358, 349, 339, 330, 321, 312, 302, 293, 284, 275, 266, 257, 248, 239, 230, 221, 213, 204, 195, 186, 178, 169, 160, 152, 143, 135, 126, 118, 109, 101, 93, 84, 76, 68, 60, 51, 43, 35, 27, 19, 11, 3, 8, 18, 27, 37, 47, 57, 67, 77, 86, 96, 105, 115, 125, 134, 144, 153, 162, 172, 181, 190, 199, 209, 218, 227, 236, 245, 254, 263, 272, 281, 290, 298, 307, 316, 325, 333, 342, 351, 359, 368, 376, 385, 393, 402, 410, 418, 427, 435, 443, 451, 460, 468, 476, 484, 492, 500, 508, 507, 499, 491, 483, 475, 467, 459, 451, 444, 436, 428, 420, 413, 405, 397, 390, 382, 375, 367, 360, 352, 345, 337, 330, 323, 315, 308, 301, 293, 286, 279, 272, 264, 257, 250, 243, 236, 229, 222, 215, 208, 201, 194, 187, 180, 173, 166, 159, 152, 146, 139, 132, 125, 118, 112, 105, 98, 92, 85, 78, 72, 65, 59, 52, 46, 39, 33, 26, 20, 13, 7, 0, 4, 12, 20, 28, 36, 44, 52, 60, 67, 75, 83, 91, 98, 106, 114, 121, 129, 136, 144, 151, 159, 166, 174, 181, 188, 196, 203, 210, 218, 225, 232, 239, 247, 254, 261, 268, 275, 282, 289, 296, 303, 310, 317, 324, 331, 338, 345, 352, 359, 365, 372, 379, 386, 393, 399, 406, 413, 419, 426, 433, 439, 446, 452, 459, 465, 472, 478, 485, 491, 498, 504, 511, 506, 500, 493, 487, 481, 474, 468, 462, 456, 449, 443, 437, 431, 425, 419, 412, 406, 400, 394, 388, 382, 376, 370, 364, 358, 352, 346, 340, 334, 328, 323, 317, 311, 305, 299, 293, 288, 282, 276, 270, 265, 259, 253, 248, 242, 236, 231, 225, 219, 214, 208, 203, 197, 191, 186, 180, 175, 169, 164, 158, 153, 147, 142, 137, 131, 126, 120, 115, 110, 104, 99, 94, 88, 83, 78, 73, 67, 62, 57, 52, 46, 41, 36, 31, 26, 21, 16, 10, 5, 0, 5, 11, 18, 24, 30, 37, 43, 49, 55, 62, 68, 74, 80, 86, 92, 99, 105, 111, 117, 123, 129, 135, 141, 147, 153, 159, 165, 171, 177, 183, 188, 194, 200, 206, 212, 218, 223, 229, 235, 241, 246, 252, 258, 263, 269, 275, 280, 286, 292, 297, 303, 308, 314, 320, 325, 331, 336, 342, 347, 353, 358, 364, 369, 374, 380, 385, 391, 396, 401, 407, 412, 417, 423, 428, 433, 438, 444, 449, 454, 459, 465, 470, 475, 480, 485, 490, 495, 501, 506, 511, 507, 502, 497, 492, 487, 482, 477, 472, 467, 462, 457, 452, 447, 442, 437, 432, 427, 422, 417, 413, 408, 403, 398, 393, 388, 384, 379, 374, 369, 364, 360, 355, 350, 345, 341, 336, 331, 326, 322, 317, 312, 308, 303, 299, 294, 289, 285, 280, 275, 271, 266, 262, 257, 253, 248, 244, 239, 235, 230, 226, 221, 217, 212, 208, 203, 199, 194, 190, 186, 181, 177, 172, 168, 164, 159, 155, 151, 146, 142, 138, 133, 129, 125, 120, 116, 112, 108, 103, 99, 95, 91, 86, 82, 78, 74, 70, 65, 61, 57, 53, 49, 45, 40, 36, 32, 28, 24, 20, 16, 12, 8, 4 };
    uint8_t  sizes[10] = { 26, 34, 42, 52, 65, 82, 103, 129, 162, 202 };
    uint16_t keys[10] = { 2, 13, 28, 47, 70, 99, 135, 181, 238, 310 };
#ifdef MAC
    TMELBANK *mel_bank = (TMELBANK *)malloc(sizeof(TMELBANK));
    mel_bank->bins = (uint16_t *)malloc(sizeof(uint16_t) * 897);
    mel_bank->sizes = (uint8_t *)malloc(sizeof(uint8_t) * 10);
    mel_bank->keys = (uint16_t *)malloc(sizeof(uint16_t) * 10);
    mel_bank->bin_len = num_bins;
    memcpy(mel_bank->bins, bins, sizeof(uint16_t) * 897);
    memcpy(mel_bank->sizes, sizes, sizeof(uint8_t) * 10);
    memcpy(mel_bank->keys, keys, sizeof(uint16_t) * 10);
#elif RISCV
    TMELBANK *mel_bank = (TMELBANK *)mymalloc(0, sizeof(TMELBANK));
    mel_bank->bins = (uint16_t *)mymalloc(0, sizeof(uint16_t) * 897);
    mel_bank->sizes = (uint8_t *)mymalloc(0, sizeof(uint8_t) * 10);
    mel_bank->keys = (uint16_t *)mymalloc(0, sizeof(uint16_t) * 10);
    mel_bank->bin_len = num_bins;
    mymemcpy(mel_bank->bins, (void *)bins, sizeof(uint16_t) * 897);
    mymemcpy(mel_bank->sizes, (void *)sizes, sizeof(uint8_t) * 10);
    mymemcpy(mel_bank->keys, (void *)keys, sizeof(uint16_t) * 10);
#elif ARM_MATH_DSP
    TMELBANK *mel_bank = (TMELBANK *)malloc(sizeof(TMELBANK));
    mel_bank->bins = (uint16_t *)malloc(sizeof(uint16_t) * 897);
    mel_bank->sizes = (uint8_t *)malloc(sizeof(uint8_t) * 10);
    mel_bank->keys = (uint16_t *)malloc(sizeof(uint16_t) * 10);
    mel_bank->bin_len = num_bins;
    memcpy(mel_bank->bins, bins, sizeof(uint16_t) * 897);
    memcpy(mel_bank->sizes, sizes, sizeof(uint8_t) * 10);
    memcpy(mel_bank->keys, keys, sizeof(uint16_t) * 10);
#endif
    return mel_bank;
}

void MfccMelInit(TMFCC *mfcc)
{
    int8_t  dct_mat_arry[100] = { 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 56, 51, 40, 25, 8, -8, -25, -40, -51, -56, 54, 33, 0, -33, -54, -54, -33, 0, 33, 54, 51, 8, -40, -56, -25, 25, 56, 40, -8, -51, 46, -17, -57, -17, 46, 46, -17, -57, -17, 46, 40, -40, -40, 40, 40, -40, -40, 40, 40, -40, 33, -54, 0, 54, -33, -33, 54, 0, -54, 33, 25, -56, 40, 8, -51, 51, -8, -40, 56, -25, 17, -46, 57, -46, 17, 17, -46, 57, -46, 17, 8, -25, 40, -51, 56, -56, 51, -40, 25, -8 };
    int16_t lifter_coeffs_arr[10] = { 256, 656, 1049, 1425, 1778, 2100, 2384, 2624, 2817, 2957 };
    int32_t num_bins = mfcc->mfcc_opt->num_bins;
    int32_t num_ceps = mfcc->mfcc_opt->num_ceps;
    mfcc->mel_len = num_bins;
    mfcc->lifter_len = num_ceps;
    mfcc->dct_row_len = num_ceps;
    mfcc->dct_col_len = num_bins;
    mfcc->mel_bank = CreateMelBanks(mfcc);
    FRAME_LEN = PaddedWindowSize(WindowSize(mfcc->mfcc_opt));
#ifdef MAC
    mfcc->fft_out = (int16_t *)malloc(sizeof(int16_t) * (FRAME_LEN * 2));
    mfcc->wavform = (int32_t *)malloc(sizeof(int32_t) * (FRAME_LEN));
    mfcc->dct_weights = (int8_t *)malloc(sizeof(int8_t) * num_ceps * num_bins);
    mfcc->mel_energies = (int32_t *)malloc(sizeof(int32_t) * num_bins);
    mfcc->lifter_coeffs = (int16_t *)malloc(sizeof(int16_t) * num_ceps);
    mfcc->window = (int16_t *)malloc(sizeof(int16_t) * FRAME_LEN);
    mfcc->window_len = WindowSize(mfcc->mfcc_opt);
    memset(mfcc->dct_weights, 0, sizeof(int8_t) * num_ceps * num_bins);
    memcpy(mfcc->dct_weights, dct_mat_arry, sizeof(int8_t) * num_ceps * num_bins);
    memset(mfcc->mel_energies, 0, sizeof(int32_t) * num_bins);
    memcpy(mfcc->lifter_coeffs, lifter_coeffs_arr, sizeof(int16_t) * 10);
#elif RISCV
    mfcc->fft_out = (int32_t *)mymalloc(0, sizeof(int32_t) * (FRAME_LEN * 2));
    mfcc->wavform = (int32_t *)mymalloc(0, sizeof(int32_t) * (FRAME_LEN));
    mfcc->dct_weights = (int8_t *)mymalloc(0, sizeof(int8_t) * num_ceps * num_bins);
    mfcc->mel_energies = (int32_t *)mymalloc(0, sizeof(int32_t) * num_bins);
    mfcc->lifter_coeffs = (int16_t *)mymalloc(0, sizeof(int16_t) * num_ceps);
    mfcc->window = (int16_t *)mymalloc(0, sizeof(int16_t) * FRAME_LEN);
    mfcc->window_len = WindowSize(mfcc->mfcc_opt);
    mymemset(mfcc->dct_weights, 0, sizeof(int8_t) * num_ceps * num_bins);
    mymemcpy(mfcc->dct_weights, dct_mat_arry, sizeof(int8_t) * num_ceps * num_bins);
    mymemset(mfcc->mel_energies, 0, sizeof(int32_t) * num_bins);
    mymemcpy(mfcc->lifter_coeffs, lifter_coeffs_arr, sizeof(int16_t) * 10);
#elif ARM_MATH_DSP
    mfcc->fft_out = (int16_t *)malloc(sizeof(int16_t) * (FRAME_LEN * 2));
    mfcc->wavform = (int32_t *)malloc(sizeof(int32_t) * (FRAME_LEN));
    mfcc->dct_weights = (int8_t *)malloc(sizeof(int8_t) * num_ceps * num_bins);
    mfcc->mel_energies = (int32_t *)malloc(sizeof(int32_t) * num_bins);
    mfcc->lifter_coeffs = (int16_t *)malloc(sizeof(int16_t) * num_ceps);
    mfcc->window = (int16_t *)malloc(sizeof(int16_t) * FRAME_LEN);
    mfcc->window_len = WindowSize(mfcc->mfcc_opt);
    memset(mfcc->dct_weights, 0, sizeof(int8_t) * num_ceps * num_bins);
    memcpy(mfcc->dct_weights, dct_mat_arry, sizeof(int8_t) * num_ceps * num_bins);
    memset(mfcc->mel_energies, 0, sizeof(int32_t) * num_bins);
    memcpy(mfcc->lifter_coeffs, lifter_coeffs_arr, sizeof(int16_t) * 10);
#endif
}