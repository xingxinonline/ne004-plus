#ifdef MAC
    #include <string.h>
    #include <stdlib.h>
#elif RISCV
    #include "malloc.h"
#elif ARM_MATH_DSP
    #include <string.h>
    #include <stdlib.h>
#endif
// #include <math.h>
#include "mfcc_win.h"
#include "mfcc_tools.h"
#include "mfcc_type.h"
#ifdef RISCV
    #define RAND_MAX 2147483647
#endif
extern inline int32_t WindowSize(TMFCCOPT *opt);
extern inline int32_t WindowShift(TMFCCOPT *opt);

static uint16_t window_tab[1024] = { 0, 3, 12, 25, 41, 60, 82, 106, 133, 163, 195, 229, 266, 305, 345, 388, 433, 480, 529, 580, 633, 688, 744, 802, 862, 924, 987, 1052, 1119, 1188, 1257, 1329, 1402, 1477, 1553, 1631, 1710, 1791, 1873, 1956, 2041, 2127, 2215, 2304, 2395, 2486, 2580, 2674, 2770, 2866, 2965, 3064, 3165, 3266, 3369, 3474, 3579, 3685, 3793, 3902, 4011, 4122, 4234, 4347, 4461, 4577, 4693, 4810, 4928, 5047, 5167, 5288, 5410, 5533, 5656, 5781, 5906, 6033, 6160, 6288, 6417, 6547, 6677, 6808, 6940, 7073, 7207, 7341, 7476, 7611, 7748, 7885, 8022, 8161, 8300, 8439, 8579, 8720, 8862, 9004, 9146, 9289, 9433, 9577, 9721, 9866, 10012, 10158, 10304, 10451, 10598, 10746, 10894, 11043, 11192, 11341, 11490, 11640, 11791, 11941, 12092, 12243, 12394, 12546, 12698, 12850, 13002, 13155, 13307, 13460, 13613, 13766, 13920, 14073, 14227, 14380, 14534, 14688, 14842, 14996, 15149, 15303, 15457, 15611, 15765, 15919, 16073, 16227, 16381, 16534, 16688, 16841, 16995, 17148, 17301, 17454, 17607, 17760, 17912, 18064, 18216, 18368, 18519, 18671, 18822, 18972, 19123, 19273, 19423, 19572, 19722, 19870, 20019, 20167, 20315, 20462, 20609, 20755, 20901, 21047, 21192, 21337, 21481, 21625, 21768, 21911, 22053, 22195, 22336, 22477, 22617, 22756, 22895, 23034, 23171, 23308, 23445, 23581, 23716, 23850, 23984, 24117, 24250, 24381, 24513, 24643, 24772, 24901, 25029, 25157, 25283, 25409, 25534, 25658, 25782, 25904, 26026, 26147, 26267, 26386, 26505, 26622, 26739, 26855, 26969, 27083, 27196, 27308, 27420, 27530, 27639, 27747, 27855, 27961, 28066, 28171, 28274, 28376, 28478, 28578, 28677, 28776, 28873, 28969, 29064, 29158, 29251, 29343, 29434, 29523, 29612, 29699, 29786, 29871, 29955, 30038, 30120, 30200, 30280, 30358, 30435, 30511, 30586, 30660, 30732, 30804, 30874, 30943, 31010, 31077, 31142, 31206, 31269, 31330, 31391, 31450, 31508, 31564, 31619, 31674, 31726, 31778, 31828, 31877, 31925, 31971, 32016, 32060, 32103, 32144, 32184, 32222, 32260, 32296, 32331, 32364, 32396, 32427, 32456, 32484, 32511, 32537, 32561, 32584, 32605, 32625, 32644, 32661, 32678, 32692, 32706, 32718, 32729, 32738, 32746, 32753, 32758, 32762, 32765, 32766, 32766, 32765, 32762, 32758, 32753, 32746, 32738, 32729, 32718, 32706, 32692, 32678, 32661, 32644, 32625, 32605, 32584, 32561, 32537, 32511, 32484, 32456, 32427, 32396, 32364, 32331, 32296, 32260, 32222, 32184, 32144, 32103, 32060, 32016, 31971, 31925, 31877, 31828, 31778, 31726, 31674, 31619, 31564, 31508, 31450, 31391, 31330, 31269, 31206, 31142, 31077, 31010, 30943, 30874, 30804, 30732, 30660, 30586, 30511, 30435, 30358, 30280, 30200, 30120, 30038, 29955, 29871, 29786, 29699, 29612, 29523, 29434, 29343, 29251, 29158, 29064, 28969, 28873, 28776, 28677, 28578, 28478, 28376, 28274, 28171, 28066, 27961, 27855, 27747, 27639, 27530, 27420, 27308, 27196, 27083, 26969, 26855, 26739, 26622, 26505, 26386, 26267, 26147, 26026, 25904, 25782, 25658, 25534, 25409, 25283, 25157, 25029, 24901, 24772, 24643, 24513, 24381, 24250, 24117, 23984, 23850, 23716, 23581, 23445, 23308, 23171, 23034, 22895, 22756, 22617, 22477, 22336, 22195, 22053, 21911, 21768, 21625, 21481, 21337, 21192, 21047, 20901, 20755, 20609, 20462, 20315, 20167, 20019, 19870, 19722, 19572, 19423, 19273, 19123, 18972, 18822, 18671, 18519, 18368, 18216, 18064, 17912, 17760, 17607, 17454, 17301, 17148, 16995, 16841, 16688, 16534, 16381, 16227, 16073, 15919, 15765, 15611, 15457, 15303, 15149, 14996, 14842, 14688, 14534, 14380, 14227, 14073, 13920, 13766, 13613, 13460, 13307, 13155, 13002, 12850, 12698, 12546, 12394, 12243, 12092, 11941, 11791, 11640, 11490, 11341, 11192, 11043, 10894, 10746, 10598, 10451, 10304, 10158, 10012, 9866, 9721, 9577, 9433, 9289, 9146, 9004, 8862, 8720, 8579, 8439, 8300, 8161, 8022, 7885, 7748, 7611, 7476, 7341, 7207, 7073, 6940, 6808, 6677, 6547, 6417, 6288, 6160, 6033, 5906, 5781, 5656, 5533, 5410, 5288, 5167, 5047, 4928, 4810, 4693, 4577, 4461, 4347, 4234, 4122, 4011, 3902, 3793, 3685, 3579, 3474, 3369, 3266, 3165, 3064, 2965, 2866, 2770, 2674, 2580, 2486, 2395, 2304, 2215, 2127, 2041, 1956, 1873, 1791, 1710, 1631, 1553, 1477, 1402, 1329, 1257, 1188, 1119, 1052, 987, 924, 862, 802, 744, 688, 633, 580, 529, 480, 433, 388, 345, 305, 266, 229, 195, 163, 133, 106, 82, 60, 41, 25, 12, 3, 0 };
int32_t FirstSampleOfFrame(int16_t frame, TMFCCOPT *opts)
{
    int32_t frame_shift = WindowShift(opts);
    if (opts->snip_edges)
    {
        return frame * frame_shift;
    }
    else
    {
        int32_t midpoint_of_frame = frame_shift * frame + frame_shift / 2,
                beginning_of_frame = midpoint_of_frame - WindowSize(opts) / 2;
        return beginning_of_frame;
    }
}

void preemphasize(int16_t *waveform, int32_t wave_len, uint8_t preemph_coeff)
{
    for (int32_t i = wave_len - 1; i > 0; i--)
    {
        waveform[i] = waveform[i] - ((preemph_coeff * waveform[i - 1]) >> 8);
    }
    waveform[0] = waveform[0] - ((preemph_coeff * waveform[0]) >> 8);
}

void ProcessWindow(TMFCC   *mfcc,
                   int16_t *window,
                   int16_t  frame_length)
{
    int32_t means = Sum_Int16(window, frame_length) / frame_length;
    Add_Int16(window, frame_length, -means);
    preemphasize(window, frame_length, mfcc->mfcc_opt->preemph_coeff);
    Multiply_Int16_ShiftRight(window, mfcc->window_weights, mfcc->window_len, 15);
    // Multiply_Int16_ShiftRight(window, mfcc->window_weights, mfcc->window_len, 12);
}

void ExtractWindow(int16_t *wave,
                   uint32_t wave_len,
                   int16_t  f,
                   TMFCC   *mfcc)
{
    int16_t sample_offset = 0;
    int16_t frame_length = WindowSize(mfcc->mfcc_opt);
    int16_t frame_length_padded = PaddedWindowSize(frame_length); // 默认到补0到2的指数
    // int32_t num_samples = sample_offset + wave_len;
    int32_t start_sample = FirstSampleOfFrame(f, mfcc->mfcc_opt);
    // int32_t end_sample = start_sample + frame_length;
    int16_t  *window = mfcc->window;
    int32_t   wave_start = start_sample - sample_offset;
    uint32_t  wave_end = wave_start + frame_length;
    if (wave_start >= 0 && wave_end <= wave_len)
    {
        for (int16_t i = 0; i < frame_length; ++i)
        {
            window[i] = wave[wave_start + i];
        }
    }
    else
    {
        for (int32_t s = 0; s < frame_length; s++)
        {
            int32_t s_in_wave = s + wave_start;
            while (s_in_wave < 0 || s_in_wave >= (int32_t)wave_len)
            {
                if (s_in_wave < 0)
                {
                    s_in_wave = -s_in_wave - 1;
                }
                else
                {
                    s_in_wave = 2 * wave_len - 1 - s_in_wave;
                }
            }
            window[s] = wave[s_in_wave];
        }
    }
    if (frame_length_padded > frame_length)
    {
#ifdef MAC
        memset(window + frame_length, 0, sizeof(int16_t) * (frame_length_padded - frame_length));
#elif RISCV
        mymemset(window + frame_length, 0, sizeof(int16_t) * (frame_length_padded - frame_length));
#elif ARM_MATH_DSP
        memset(window + frame_length, 0, sizeof(int16_t) * (frame_length_padded - frame_length));
#endif
    }
    ProcessWindow(mfcc, window, frame_length);
}

int16_t NumFrames(int32_t num_samples, TMFCC *mfcc)
{
    int32_t frame_shift = WindowShift(mfcc->mfcc_opt);
    int32_t frame_length = WindowSize(mfcc->mfcc_opt);
    if (mfcc->mfcc_opt->snip_edges)
    {
        if (num_samples < frame_length)
            return 0;
        else
            return (1 + ((num_samples - frame_length) / frame_shift));
    }
    else
    {
        int16_t num_frames = (num_samples + (frame_shift / 2)) / frame_shift;
        return num_frames;
    }
}

void MfccWindowInit(TMFCC *mfcc)
{
    TMFCCOPT *opts = mfcc->mfcc_opt;
    int32_t   frame_length = PaddedWindowSize(WindowSize(opts));
#ifdef MAC
    mfcc->window_weights = (uint16_t *)malloc(sizeof(uint16_t) * frame_length);
#elif RISCV
    mfcc->window_weights = (uint16_t *)mymalloc(0, sizeof(uint16_t) * frame_length);
#elif ARM_MATH_DSP
    mfcc->window_weights = (uint16_t *)malloc(sizeof(uint16_t) * frame_length);
#endif
#ifdef MAC
    memcpy(mfcc->window_weights, window_tab, sizeof(uint16_t) * frame_length);
#elif RISCV
    mymemcpy(mfcc->window_weights, (void *)window_tab, sizeof(uint16_t) * frame_length);
#elif ARM_MATH_DSP
    memcpy(mfcc->window_weights, window_tab, sizeof(uint16_t) * frame_length);
#endif
}
