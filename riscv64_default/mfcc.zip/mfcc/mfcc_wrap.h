#ifndef __MFCC_WRAP_H__
#define __MFCC_WRAP_H__
#include "mfcc_type.h"
#include "mfcc_mel.h"
#include "mfcc_win.h"

#endif